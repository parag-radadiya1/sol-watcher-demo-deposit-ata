export * from './assetsType.constant';
